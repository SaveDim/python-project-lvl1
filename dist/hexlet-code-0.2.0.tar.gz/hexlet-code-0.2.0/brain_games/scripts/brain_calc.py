# -*- coding example -*-.

"""Add calc game."""

# !/usr/bin/env python

from brain_games.games import calc


def main():
    """Calc game code."""
    calc_game()


if __name__ == '__main__':
    main()
