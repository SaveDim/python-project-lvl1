# -*- coding example -*-.

"""Add greeting to the game."""

#!/usr/bin/env python

from brain_games.games.games_logic import calc_game


def main():
    """Calc game code."""
    calc_game()


if __name__ == '__main__':
    main()
