# -*- coding example -*-.

"""Add greeting to the game."""

#!/usr/bin/env python

from brain_games.games.games_logic import find_skipped_number


def main():
    """Calc game code."""
    find_skipped_number()


if __name__ == '__main__':
    main()
