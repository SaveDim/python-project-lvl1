# -*- coding example -*-.

"""Add progression game."""

#!/usr/bin/env python

from brain_games.games.games_logic import find_skipped_number


def main():
    """Progression game code."""
    find_skipped_number()


if __name__ == '__main__':
    main()
