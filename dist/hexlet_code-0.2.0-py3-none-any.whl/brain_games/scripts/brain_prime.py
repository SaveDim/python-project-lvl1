# -*- coding example -*-.

"""Add prime game."""

# !/usr/bin/env python

from brain_games.games.prime import is_prime


def main():
    """Prime game code."""
    is_prime()


if __name__ == '__main__':
    main()
