# -*- coding example -*-.

"""Add gcd game."""

# !/usr/bin/env python

from brain_games.games.gcd import find_gcd


def main():
    """Gcd game code."""
    find_gcd()


if __name__ == '__main__':
    main()
