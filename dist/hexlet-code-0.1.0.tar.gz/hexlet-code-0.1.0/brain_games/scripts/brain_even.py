# -*- coding example -*-.

"""Add greeting to the game."""

#!/usr/bin/env python

from brain_games.even_logic import even_game

def main():
    """Even game code."""
    even_game()

if __name__ == '__main__':
    main()

